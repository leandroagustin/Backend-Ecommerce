const fs = require("fs");

const writeFileAsync = async (arr) => {
  await fs.promises.writeFile("./productos.txt", JSON.stringify(arr, null, 2), "utf-8");
};

const readFileAsync = async (arr) => {
  let file = await fs.promises.readFile("./productos.txt", "utf-8");
  return file;
};

const getItemInArray = (data,id) => {
  return data.find((item) => item.id === id);
}

class Contenedor {
  constructor() {
    this.pr = [];
  }

  async save(product) {
    let fileExits = await readFileAsync(); //String
    if (fileExits && fileExits.length >= 0) {
      let dataFile = JSON.parse(fileExits);
      product.id = dataFile.length + 1;
      dataFile.push(product);
      this.pr = dataFile;
      writeFileAsync(this.pr);
    } else {
      product.id = 1;
      this.pr.push(product);
      writeFileAsync(this.pr);
    }
  };
  async getById(id) {
    let productId = await readFileAsync();
    if (productId && productId.length >= 0) {
      let dataFile = JSON.parse(productId);
      const itemFound = dataFile.find((item) => item.id === id);
      return itemFound;
    }
    return null;
  };
  async getAll() {
    return await readFileAsync(this.pr);
  }
  async deleteById(id) {
      let data = await readFileAsync(this.pr)
    if (getItemInArray(data, id)) {
      let dataFile = JSON.parse(productId);
      const newData = dataFile.filter((item) => item.id !== id)
      await writeFileAsync(this.pr, newData)
      return "se elimino correctamente"
    } else {
      throw `no existe el id ${id}.`
    }
  }
  async deleteAll() {
    await writeFileAsync(this.pr, "[]");
  };
};

let c = new Contenedor();

// c.save({
//   title: "bike",
//   price: 1000,
//   thumbnail: "www.google.com"
// });
// console.log(c.getById(3));
c.deleteById(9);
// c.deleteAll();